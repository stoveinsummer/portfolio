import type { Metadata } from "next";
import { JsonFormatter } from "@/components/JsonFormatter";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ToolContext } from "@/components/ToolContext";
import { tools } from "@/data/tools";

export const metadata: Metadata = { title: "JSON 정렬기", description: "브라우저에서 안전하게 JSON을 검사하고 정렬하는 도구." };
export default function JsonFormatterPage() { const tool = tools.find((item) => item.id === "json-formatter")!; return <main className="portfolio"><SiteHeader active="Tools" /><div className="tool-detail-head"><p className="eyebrow">Tool 01 · Local only</p><h1>JSON 정렬기</h1><p>JSON을 붙여넣어 문법을 확인하고, 읽기 좋은 형태로 정렬하거나 한 줄로 압축합니다.</p></div><div className="tool-detail-content"><JsonFormatter /><ToolContext tool={tool} /><a className="back-link" href="/tools">← 도구 목록</a></div><SiteFooter /></main>; }
